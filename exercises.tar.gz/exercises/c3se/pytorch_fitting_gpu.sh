#!/bin/bash
# Remember to change this to your own project ID!
#SBATCH -A NAISS2025-22-934
# We are asking for 5 minutes
#SBATCH --time=00:05:00
# The following two lines splits the output in a file for any errors and a file for other output.
#SBATCH --error=job.%J.err
#SBATCH --output=job.%J.out
#SBATCH -p alvis
#SBATCH -N 1 --gpus-per-node=T4:4

# Remove any loaded modules and load the ones we need
module purge  > /dev/null 2>&1
module load Python/3.11.3-GCCcore-12.3.0 OpenMPI/4.1.5-GCC-12.3.0 SciPy-bundle/2023.07-gfbf-2023a PyTorch/2.1.2-foss-2023a-CUDA-12.1.1

srun python pytorch_fitting_gpu.py

