#!/bin/bash
# Change to your own project ID! 
#SBATCH -A NAISS2025-22-934 
#SBATCH --time=00:20:00 # Asking for 20 minutes
#SBATCH -p alvis
# You need to ask for a GPU to run on alvis.
# This is a CPU job. Do not do things like this normally!
# Only use for GPU jobs!
#SBATCH --gpus-per-node=T4:1
#SBATCH -n 1 -c 1 # Asking for 1 core    # one core per task

# Load any modules you need, here for Python 3.11.3 and compatible SciPy-bundle
module purge  > /dev/null 2>&1
module load GCC/12.3.0 OpenMPI/4.1.5 Python/3.11.3 SciPy-bundle/2023.07

# Run your Python script
python mmmult.py

